# TcpFlow

this library is a wrapper around the cli tcpflow to check the outgoing requests urls

developed by [Michel Perez](https://github.com/mrkaspa)


